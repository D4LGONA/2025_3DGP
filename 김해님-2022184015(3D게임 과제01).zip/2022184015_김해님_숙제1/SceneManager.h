// SceneManager.h
#pragma once

#include "stdafx.h"
#include "Scene.h"

class SceneManager 
{
private:
public:
	bool ChangeScene = false;
	int idx = 0;
};